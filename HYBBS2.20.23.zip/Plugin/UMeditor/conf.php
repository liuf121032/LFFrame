<?php
return array(
    'name' => '百度 UMeditor',
    'user' => 'krabs',
    'icon' => 'edit',
    'mess' => '百度编辑器 迷你版 内核版本:1.2.2 仅用于PC',
    'version' => '2.2'
);
