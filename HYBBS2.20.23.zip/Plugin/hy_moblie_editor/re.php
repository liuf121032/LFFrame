<?php
return array(
	'View/hy_moblie/thread_index.html'=>array(
		'a1'=>'b1'
	)
);