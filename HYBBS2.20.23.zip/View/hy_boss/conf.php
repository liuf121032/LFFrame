<?php


return array(
	'name'=>'官方BBS模板',
	'mess'=>'这是HYBBS默认模板',
	'user'=>'krabs',
	'version' => '2.0',
);