<?php !defined('HY_PATH') && exit('HY_PATH not defined.'); ?>
{"menu_fix":"0","menu_forum":"0","max":"0","diy_link":"","width":"","css":"","forum_html_on":"0"}