<?php
return array(
	'最新主题'=>'The Latest Thread',
	'最新回复'=>'The Latest Reply',
	'论坛首页'=>'Home',
	'发表新主题'=>'Post New Thread',
	'全站置顶'=>'Top For ALL',
	'本版置顶'=>'Top For Module',
	'发表于'=>'to',
	'最后回复'=>'The Last Reply',
	'上一页'=>'Previous Page',
	'下一页'=>'Next Page',
	'程序版本'=>'Version',
	'全部板块'=>'All Module',
	'宽屏'=>'Widescreen',
	'注册'=>'Register',
	'登录'=>'Login',

	'已锁定'=>'Locked',
	'禁止回复'=>'No Reply',
	'内容隐藏提示'=>'The content is hidden and you need to reply to the topic before it becomes visible.',
	'付费可见'=>'Subject content you need to pay for watching',
	'点击购买'=>'Click To Buy',
	'售价'=>'Price',
	'金币'=>'Gold',
	'支持'=>'Support',
	'反对'=>'Against',
	'编辑'=>'Edit',
	'删除主题'=>'Delete Thread',
	'解锁帖子'=>'Unlock Posts',
	'锁定帖子'=>'Lock Posts',
	'取消板块置顶'=>'Cancel Top To Modules',
	'板块置顶'=>'Top To Modules',
	'取消全站置顶'=>'Cancel Top To ALL',
	'全站置顶'=>'Top To ALL',
	'附件列表'=>'Attachment List',
	'文件大小'=>'File Size',
	'下载次数'=>'Download Count',
	'售价'=>'Price',
	'附件隐藏'=>'The attachment is hidden and you need to reply to the topic before it becomes visible.',
	'条回复'=>'Reply',
	'直到'=>'Until',
	'次浏览'=>'View',
	'最早回复'=>'The First Reply',

	
	'删除帖子'=>'Delete Posts',
	'后才可发表内容'=>'Can Publish Content',
	


	

);