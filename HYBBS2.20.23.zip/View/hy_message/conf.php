<?php


return array(
	'name'=>'官方消息模板',
	'mess'=>'官方消息模板',
	'user'=>'krabs',
	);